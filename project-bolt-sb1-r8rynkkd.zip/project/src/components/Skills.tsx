import React from 'react';
import { Bot, Code2, Database, Globe, Zap, Shield } from 'lucide-react';

const Skills: React.FC = () => {
  const skillCategories = [
    {
      title: 'AI & Prompt Engineering',
      icon: <Bot className="w-6 h-6" />,
      color: 'blue',
      skills: [
        { name: 'GPT Prompt Optimization', level: 95 },
        { name: 'AI Code Generation', level: 90 },
        { name: 'Claude & ChatGPT Integration', level: 92 },
        { name: 'AI-Assisted Debugging', level: 88 }
      ]
    },
    {
      title: 'Frontend Development',
      icon: <Globe className="w-6 h-6" />,
      color: 'green',
      skills: [
        { name: 'React/TypeScript', level: 92 },
        { name: 'Next.js', level: 88 },
        { name: 'Tailwind CSS', level: 90 },
        { name: 'Modern JavaScript', level: 94 }
      ]
    },
    {
      title: 'Backend & Database',
      icon: <Database className="w-6 h-6" />,
      color: 'purple',
      skills: [
        { name: 'Node.js/Express', level: 85 },
        { name: 'PostgreSQL/MongoDB', level: 82 },
        { name: 'API Development', level: 88 },
        { name: 'Supabase/Firebase', level: 86 }
      ]
    },
    {
      title: 'Development Tools',
      icon: <Code2 className="w-6 h-6" />,
      color: 'orange',
      skills: [
        { name: 'Git/GitHub', level: 90 },
        { name: 'VS Code Extensions', level: 88 },
        { name: 'Docker', level: 80 },
        { name: 'CI/CD Pipelines', level: 78 }
      ]
    },
    {
      title: 'AI-Enhanced QA',
      icon: <Shield className="w-6 h-6" />,
      color: 'red',
      skills: [
        { name: 'Automated Testing', level: 85 },
        { name: 'Code Review Automation', level: 88 },
        { name: 'Error Pattern Recognition', level: 90 },
        { name: 'Performance Monitoring', level: 82 }
      ]
    },
    {
      title: 'Optimization',
      icon: <Zap className="w-6 h-6" />,
      color: 'yellow',
      skills: [
        { name: 'Performance Tuning', level: 87 },
        { name: 'SEO Optimization', level: 85 },
        { name: 'Bundle Analysis', level: 83 },
        { name: 'Core Web Vitals', level: 88 }
      ]
    }
  ];

  const getColorClasses = (color: string) => {
    const colors: { [key: string]: { bg: string; text: string; progress: string } } = {
      blue: { bg: 'bg-blue-100', text: 'text-blue-600', progress: 'bg-blue-500' },
      green: { bg: 'bg-green-100', text: 'text-green-600', progress: 'bg-green-500' },
      purple: { bg: 'bg-purple-100', text: 'text-purple-600', progress: 'bg-purple-500' },
      orange: { bg: 'bg-orange-100', text: 'text-orange-600', progress: 'bg-orange-500' },
      red: { bg: 'bg-red-100', text: 'text-red-600', progress: 'bg-red-500' },
      yellow: { bg: 'bg-yellow-100', text: 'text-yellow-600', progress: 'bg-yellow-500' }
    };
    return colors[color];
  };

  return (
    <section id="skills" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-800 mb-4">
              Technical Skills
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto mb-6"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive expertise in AI-enhanced development, modern web technologies, 
              and intelligent automation tools.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skillCategories.map((category, index) => {
              const colorClasses = getColorClasses(category.color);
              return (
                <div 
                  key={index} 
                  className="bg-slate-50 rounded-xl p-6 hover:shadow-lg transition-shadow duration-300"
                >
                  <div className="flex items-center mb-4">
                    <div className={`${colorClasses.bg} ${colorClasses.text} p-2 rounded-lg mr-3`}>
                      {category.icon}
                    </div>
                    <h3 className="text-lg font-semibold text-slate-800">{category.title}</h3>
                  </div>
                  
                  <div className="space-y-4">
                    {category.skills.map((skill, skillIndex) => (
                      <div key={skillIndex}>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-slate-700">{skill.name}</span>
                          <span className="text-sm text-slate-500">{skill.level}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`${colorClasses.progress} h-2 rounded-full transition-all duration-1000 ease-out`}
                            style={{ width: `${skill.level}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;