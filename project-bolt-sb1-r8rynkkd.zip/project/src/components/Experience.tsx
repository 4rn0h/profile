import React from 'react';
import { Calendar, MapPin, Briefcase } from 'lucide-react';

const Experience: React.FC = () => {
  const experiences = [
    {
      title: 'Senior AI Developer',
      company: 'TechForward Solutions',
      location: 'Remote',
      period: '2023 - Present',
      description: 'Leading AI integration initiatives across multiple client projects, specializing in prompt engineering and automated development workflows. Reduced development time by 40% through intelligent code generation and optimization.',
      achievements: [
        'Implemented AI-powered code review system reducing bugs by 60%',
        'Developed custom GPT models for client-specific development needs',
        'Mentored team of 8 developers in AI-assisted development practices',
        'Led migration of legacy systems using AI-powered refactoring tools'
      ],
      technologies: ['Python', 'OpenAI API', 'React', 'Node.js', 'Docker']
    },
    {
      title: 'Full Stack Developer & AI Specialist',
      company: 'InnovateTech Labs',
      location: 'San Francisco, CA',
      period: '2022 - 2023',
      description: 'Pioneered the integration of AI tools into the development pipeline, creating automated testing suites and intelligent debugging systems. Built scalable web applications with focus on performance and user experience.',
      achievements: [
        'Built AI-powered customer support chatbot serving 10k+ users daily',
        'Optimized application performance improving Core Web Vitals by 35%',
        'Created automated deployment pipeline reducing release time by 50%',
        'Developed real-time analytics dashboard for business intelligence'
      ],
      technologies: ['JavaScript', 'React', 'Next.js', 'PostgreSQL', 'AWS']
    },
    {
      title: 'Web Developer',
      company: 'Digital Craft Agency',
      location: 'New York, NY',
      period: '2021 - 2022',
      description: 'Focused on creating responsive, accessible web applications while exploring emerging AI technologies. Collaborated with design teams to deliver pixel-perfect implementations and optimal user experiences.',
      achievements: [
        'Delivered 15+ client projects with 98% satisfaction rate',
        'Implemented accessibility standards achieving WCAG 2.1 AA compliance',
        'Reduced page load times by 45% through optimization techniques',
        'Established coding standards and best practices for the team'
      ],
      technologies: ['HTML', 'CSS', 'JavaScript', 'Vue.js', 'PHP', 'MySQL']
    },
    {
      title: 'Junior Developer',
      company: 'StartupHub Inc.',
      location: 'Austin, TX',
      period: '2020 - 2021',
      description: 'Gained foundational experience in web development while beginning exploration of AI tools and automation. Contributed to various startup projects and learned rapid prototyping techniques.',
      achievements: [
        'Built MVP applications for 5 early-stage startups',
        'Learned and implemented modern JavaScript frameworks',
        'Participated in code reviews and agile development processes',
        'Began experimenting with AI-assisted coding tools'
      ],
      technologies: ['JavaScript', 'React', 'Node.js', 'MongoDB', 'Git']
    }
  ];

  return (
    <section id="experience" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-800 mb-4">
              Professional Experience
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto mb-6"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A progressive journey through the evolving landscape of AI-enhanced development, 
              building expertise in cutting-edge technologies and innovative solutions.
            </p>
          </div>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-blue-500 to-green-500"></div>

            {experiences.map((experience, index) => (
              <div key={index} className="relative pl-20 pb-12 last:pb-0">
                {/* Timeline dot */}
                <div className="absolute left-6 w-4 h-4 bg-white border-4 border-blue-500 rounded-full"></div>

                <div className="bg-slate-50 rounded-xl p-6 hover:shadow-lg transition-shadow duration-300">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-slate-800 mb-1">{experience.title}</h3>
                      <div className="flex items-center text-blue-600 font-semibold mb-2">
                        <Briefcase className="w-4 h-4 mr-2" />
                        {experience.company}
                      </div>
                    </div>
                    <div className="flex flex-col md:items-end text-sm text-gray-600">
                      <div className="flex items-center mb-1">
                        <Calendar className="w-4 h-4 mr-1" />
                        {experience.period}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 mr-1" />
                        {experience.location}
                      </div>
                    </div>
                  </div>

                  <p className="text-gray-700 mb-4 leading-relaxed">{experience.description}</p>

                  <div className="mb-4">
                    <h4 className="font-semibold text-slate-800 mb-2">Key Achievements:</h4>
                    <ul className="space-y-1">
                      {experience.achievements.map((achievement, achievementIndex) => (
                        <li key={achievementIndex} className="flex items-start">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                          <span className="text-gray-700 text-sm">{achievement}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {experience.technologies.map((tech, techIndex) => (
                      <span 
                        key={techIndex}
                        className="bg-white text-slate-700 px-3 py-1 rounded-full text-sm font-medium border border-slate-200"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;