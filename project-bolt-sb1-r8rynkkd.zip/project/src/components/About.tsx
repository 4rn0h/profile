import React from 'react';
import { Brain, Code, Zap, CheckCircle } from 'lucide-react';

const About: React.FC = () => {
  const highlights = [
    'AI Prompt Engineering Expert',
    'Full-Stack Web Development',
    'Automated Bug Detection & Fixing',
    'Code Quality Optimization',
    'AI-Assisted Development Workflows',
    'Modern Framework Proficiency'
  ];

  return (
    <section id="about" className="py-20 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-800 mb-4">
              About Me
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-green-500 mx-auto mb-6"></div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Passionate developer leveraging AI to create exceptional digital experiences
              and solve complex technical challenges with innovative solutions.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="prose prose-lg text-gray-700">
                <p className="text-lg leading-relaxed">
                  As a forward-thinking developer, I specialize in harnessing the power of artificial intelligence 
                  to enhance every aspect of the development process. From intelligent prompt engineering to 
                  automated code optimization, I bridge the gap between human creativity and AI efficiency.
                </p>
                <p className="text-lg leading-relaxed">
                  My expertise spans modern web technologies, with a particular focus on using AI tools to 
                  streamline development workflows, identify and fix bugs proactively, and ensure code quality 
                  that exceeds industry standards.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {highlights.map((highlight, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-gray-700 font-medium">{highlight}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 text-center group">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-200 transition-colors duration-300">
                  <Brain className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold text-slate-800 mb-2">AI Strategy</h3>
                <p className="text-gray-600 text-sm">Crafting intelligent solutions through advanced prompt engineering</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 text-center group">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:bg-green-200 transition-colors duration-300">
                  <Code className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold text-slate-800 mb-2">Development</h3>
                <p className="text-gray-600 text-sm">Building scalable applications with modern frameworks</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 text-center group col-span-2">
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:bg-yellow-200 transition-colors duration-300">
                  <Zap className="w-6 h-6 text-yellow-600" />
                </div>
                <h3 className="font-semibold text-slate-800 mb-2">Optimization</h3>
                <p className="text-gray-600 text-sm">Automated bug detection, error checking, and performance enhancement</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;